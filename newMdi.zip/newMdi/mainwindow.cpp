#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtWidgets>
#include "mainwindow.h"
#include <QDebug>
#include <QAction>
#include <QApplication>
#include <QMenu>
#include <QMenuBar>
#include <QTextEdit>
#include <QMessageBox>
#include <QGridLayout>
#include <QSpacerItem>
#include <QVBoxLayout>
#include <QFrame>
#include <iostream>
using namespace std;

MainWindow::MainWindow()
    :ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    mdiArea= new QMdiArea;
    mdiArea->setParent(this);

    setCentralWidget(mdiArea);
    mdiArea->setGeometry(0,0,800,800);
    mdiArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    mdiArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);

}

MainWindow::~MainWindow()
{
    delete ui;
    qDebug()<<"~MainWindow()\r\n";
}


int MainWindow::validateAcc(Input *fld)
{
    if (fld->text().isEmpty()) {
        qDebug()<<"A/C Should not be blank \r\n";
         return 1;
    }
    else{
        qDebug()<<"In A/c validation \r\n";
        return 0;
    }
}

void MainWindow::on_actionnew_triggered()
{
    qDebug()<<"New Call";

    subWindow = new QMdiSubWindow();
    subWindow->setParent(mdiArea);
    subWindow->setWindowIcon(QIcon(QPixmap(1,1)));


    subWindow->setGeometry(20,20,400,400);
    subWindow->showNormal();

    QWidget *w = new QWidget();
    subWindow->setWidget(w);
    w->setGeometry(20,20,400,400);

    subWindow->setWindowFlags( (windowFlags() | Qt::CustomizeWindowHint) & ~Qt::WindowMaximizeButtonHint);

    glay = new QGridLayout; //--------GRidlayout Object------------
    vlay = new QVBoxLayout;

// -----------------LABEL   AND  INPUT --------------------------

    label1 = new Label(10,40,100,25,"Account NO",subWindow);
    glay->addWidget(label1,0,0);

    input1 = new Input(120, 80, 150, 25, "Acc No", subWindow);
    input1->setvalidate(MainWindow::validateAcc);
    glay->addWidget(input1,0,1);

    label2 = new Label(10,80,120,25,"Account Name",subWindow);
    glay->addWidget(label2,1,0);

    input2 = new Input(120, 80, 150, 25, "Acc holder name", subWindow);
    glay->addWidget(input2,1,1);

    label3 = new Label(10,120,120,25,"contact no",subWindow);
    glay->addWidget(label3,2,0);

    input3= new Input(120,120,150,25,"contact no",subWindow);
    input3->setvalidate(MainWindow::validateAcc);
    input3->setInputMask("9999999999");


    QVBoxLayout *vlay= new QVBoxLayout;
    vlay->setSpacing(1);

    //------------------- Buttons ------------------------

    submit= new pushbutton(10,350,70,25,"submit",subWindow);
    connect(submit,SIGNAL(clicked()), this,SLOT(submitcall()));


    QSpacerItem *spacer=new QSpacerItem(70,500,QSizePolicy::Expanding,
                                            QSizePolicy::Maximum);


    viewfile= new pushbutton(100,350,70,25,"view file",subWindow);

    connect(viewfile,SIGNAL(clicked()), this,SLOT(viewFile()));


    glay->addWidget(submit,3,0);
    glay->addWidget(viewfile,3,2);
    glay->addWidget(input3,2,1);
    glay->addItem(spacer,3,1);
  //------------- vertical layout------------------

//    vlay->addWidget(submit);
//    vlay->addItem(spacer);
//    vlay->addWidget(viewfile);

    w->setLayout(glay);
    w->show();
}



void MainWindow::on_actionfile_triggered()
{

    subWindow = new QMdiSubWindow;
    subWindow->setParent(mdiArea);


    subWindow->setGeometry(20,20,600,600);
    subWindow->showNormal();
subWindow->setMinimumHeight(500);
subWindow->setMinimumWidth(500);

    QWidget *w = new QWidget();
    subWindow->setWidget(w);

    //--- Layour object creation-------------
    glay = new QGridLayout;
    vlay = new QVBoxLayout;

    frame1 = new Frame(0,0,200,50,w);

    glay->addWidget(frame1,0,0);

   frame2 = new Frame(0,0,200,50,w);
   frame2->setMaximumHeight(100);
   frame2->setMaximumHeight(100);
   glay->addWidget(frame2,1,0);



   //QFormLayout *form = new QFormLayout;
    menu = new MenuBar(frame2);
    vlay->addWidget(menu);

   Input *msgl;
   msgl= new Input(10,10,100,20,"label 1",frame2);
   vlay->addWidget(msgl);

//   Label *msgl2;
//   msgl2 = new Label(100,10,100,20,"label 2", frame2);
//   vlay->addWidget(msgl2);

   frame2->setLayout(vlay);

//   menu= new MenuBar(frame1);
//   menu->setGeometry(10,w->height()-100,400,25);
   glay->addLayout(vlay,1,0);
//    glay->addWidget(msgl,2,0);
//    glay->addWidget(msgl2,3,0);
    w->setLayout(glay);
    w->show();

}

void MainWindow::submitcall()
{
    qDebug()<<"button clicked";
    QFile file("/home/kimaya/Downloads/Data/data.csv");

    if(!file.open(QIODevice::WriteOnly))
    {
       std::cerr<<"Cannot open file for writing:"
               <<qPrintable(file.errorString())<<std::endl;
       return;
    }
    QTextStream in(&file);
    in<<label1->text()<<","<<label2->text()<<","<<label3->text()<<endl;
    in<<input1->text()<<","<<input2->text()<<","<<input3->text()<<endl;

}

void MainWindow::viewFile()
{
    qDebug()<<"view clicked";

    subWindow = new QMdiSubWindow();
    subWindow->setParent(mdiArea);

    subWindow->setGeometry(20,20,400,400);
    subWindow->showNormal();

    QWidget *w = new QWidget();
    subWindow->setWidget(w);
    glay = new QGridLayout;

    QTextBrowser *edit= new QTextBrowser;
    edit->setParent(w);

    glay->addWidget(edit,0,0);


    QFile file("/home/kimaya/Downloads/1_BalSheet.TXT");
    if(!file.open(QIODevice::ReadOnly))
        QMessageBox::information(0,"info", file.errorString());
    QTextStream in(&file);

    edit->setFontFamily("monospace");

    edit->setText(in.readAll());

    edit->show();

    w->setLayout(glay);

}



