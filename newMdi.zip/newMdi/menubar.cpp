#include "menubar.h"

MenuBar::MenuBar(QWidget *p): QMenuBar(p)
{
    setParent(p);
    setGeometry(5,p->height(),p->width(),25);
    QMenu *File = addMenu(tr("&File"));
    New = new QAction("New");
    File->addAction(New);
    show();

}

//MenuBar :: MenuBar(int X, int Y, int W, int H,QWidget *parent)
//{
//    setParent(parent);
//    setGeometry(X,Y,W,H);

//    QMenu *File = addMenu(tr("&File"));
//    New = new QAction("New");
//    File->addAction(New);
//    Open = new QAction("Open");
//    File->addAction(Open);
//    Quit = new QAction("Quit");
//    File->addAction(Quit);

//    QMenu *Edit = addMenu(tr("&Edit"));
//    Copy = new QAction("Copy");
//    Paste = new QAction("Paste");
//    Cut = new QAction("Cut");
//    Edit->addAction(Copy);
//    Edit->addAction(Paste);
//    Edit->addAction(Cut);



//    QMenu *About = addMenu(tr("&About"));
//    AboutApp = new QAction("AboutApp");
//    AboutMdi = new QAction("AboutMdi");
//    About->addAction(AboutApp);
//    About->addAction(AboutMdi);

//    QMenu *Exit = addMenu(tr("&Exit"));
//    Exit->addAction(Quit);
//}
