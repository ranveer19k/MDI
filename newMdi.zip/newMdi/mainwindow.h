#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMdiArea>
#include <QMainWindow>
#include <QMenu>
#include <QLabel>
#include <QLineEdit>
#include "Input.h"
#include "label.h"
#include "pushbutton.h"
#include <QPlainTextEdit>
#include "menubar.h"
#include <QGridLayout>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include "frame.h"

#include"win.h"

class QMdiArea;

class MdiChild;
class QLineEdit;
class QLabel;
class QPlainTextEdit;

//----------------------
class QAction;
class Assistant;
class TextEdit;
class QMenu;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow();
   ~MainWindow();
    QGridLayout *glay;
    QVBoxLayout *vlay;
    QHBoxLayout *hlay;

signals:
    void actionnew();
    void click();

private slots:

    void on_actionfile_triggered();
    void on_actionnew_triggered();

    void submitcall();
    void viewFile();

private:
    Ui::MainWindow *ui;
    static int validateAcc(Input *fld);

    QMdiArea *mdiArea;

    QMdiSubWindow *subWindow;

    QWidget *widget;


//----- inherited class object declaration;

    Input *input1;
    Input *input2;
    Input *input3;

    Label *label1;
    Label *label2;
    Label *label3;

    pushbutton *submit;
    pushbutton *viewfile;

    QPlainTextEdit *textarea;
    Frame *frame1;
    Frame *frame2;
    MenuBar *menu;
//----------------------------------




};
#endif // MAINWINDOW_H
