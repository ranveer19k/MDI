#include "win.h"

win::win(QWidget *parent):QMdiSubWindow(parent)
{
    setGeometry(15,25,400,400);
    setParent(parent);
    show();

}
