#ifndef FRAME_H
#define FRAME_H

#include <QFrame>
#include <QObject>

class Frame : public QFrame
{
    Q_OBJECT
public:
    Frame(int X, int Y, int W, int H, QWidget *p);
};

#endif // FRAME_H
