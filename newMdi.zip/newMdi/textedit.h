#ifndef TEXTEDIT_H
#define TEXTEDIT_H

#include <QTextEdit>
#include <QObject>

class TextEdit : public QTextEdit
{
    Q_OBJECT
public:
    TextEdit(QWidget *p=nullptr);
    void setContents(const QString &filename);

private:
    QVariant loadResource(int type, const QUrl &name) override;
    QUrl srcUrl;

};

#endif // TEXTEDIT_H
