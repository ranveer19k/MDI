#include "mdichild.h"

MdiChild::MdiChild()

{
    setAttribute(Qt::WA_DeleteOnClose);

}

MdiChild::~MdiChild()
{

}
