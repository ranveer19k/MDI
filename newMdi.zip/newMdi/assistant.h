
#ifndef ASSISTANT_H
#define ASSISTANT_H

#include <QCoreApplication>
#include <QString>

QT_BEGIN_NAMESPACE
class QProcess;
QT_END_NAMESPACE

class Assistant
{
    Q_DECLARE_TR_FUNCTIONS(Assistant)

public:
    Assistant();
    ~Assistant();
    void showDocumentation(const QString &file);

private:
    bool startAssistant();
    QProcess *proc;
};

#endif
