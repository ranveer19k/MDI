#include "frame.h"

Frame::Frame(int X, int Y, int W, int H, QWidget *p):QFrame(p)
{

    setGeometry(X, Y, W, H);
    setLineWidth(2);
   // setMidLineWidth(3);
    setFrameStyle(QFrame::Box|QFrame::Raised);
//    setFrameStyle(QFrame::VLine);
//    setFrameStyle(QFrame::HLine);

    setParent(p);
    show();

}
