#ifndef MENUBAR_H
#define MENUBAR_H

#include <QMenuBar>
#include<QMenu>
#include<QAction>

class MenuBar : public QMenuBar
{
public:
    MenuBar(QWidget *p);

    //MenuBar(int X, int Y, int H, int W,QWidget *p);


    QMenu *File;
    QMenu *Edit;
    QMenu *View;
    QMenu *About;
    QMenu *Exit;


    QAction *New;
    QAction *Open;
    QAction *Quit;

    QAction *Copy;
    QAction *Paste;
    QAction *Cut;

    QAction *AboutMdi;
    QAction *AboutApp;

};

#endif // MENUBAR_H
