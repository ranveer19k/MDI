#ifndef WIN_H
#define WIN_H

#include <QMdiSubWindow>

class win : public QMdiSubWindow
{
public:
    win(QWidget *parent);
};

#endif // WIN_H
