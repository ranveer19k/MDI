#include "dialog.h"
#include <QDebug>
#include <QMessageBox>
dialog::dialog(QWidget *p):QPlainTextEdit(p)
{
show();
getFile();

}


dialog::~dialog()
{
    qDebug()<<"~dialog()";
}

void dialog::getFile()
{

    QFile file("/home/kimaya/ProjectQt/newMdi/demo.txt");
    if(!file.open(QFile::ReadOnly | QFile::Text) )
    {
        QMessageBox::warning(this, "title", "file not opened");
    }
    QTextStream in(&file);
    QString text = in.readAll();
    plainTextEdit->setPlainText(text);

    file.close();
    qDebug()<<"in dialgo.cpp";
}
